<?php

require_once 'users/init.php';
require_once $abs_us_root . $us_url_root . 'users/includes/template/prep.php';
if (isset($user) && $user->isLoggedIn()) {
}
$db->query("SELECT * FROM clientes");

?>

<div class="container">
    <div class="row d-flex justify-content-center text-center">
        <div class="col-md">
            <h3>Listagem de clientes</h3>
            </br>
        </div>
    </div>
    <div class="row d-flex justify-content-center">
        <div class="col-md-10 table-responsive text-nowrap ">
        <a  href="cliente_cadastro.php"><button class="btn btn-success text-white">Cadastrar</button></a>
        <br><br>
            <form method="post" id="form" action="delete.php?tabela=clientes">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th scope='col'>ID</th>
                            <th scope='col'>Nome</th>
                            <th scope='col'>email</th>
                            <th scope='col'>telefone</th>
                            <th scope='col'>Excluir</th>
                            <th scope='col'>Editar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($db->results() as $results) {
                        ?>
                            <tr>
                                <th scope='row'><?php echo $results->id; ?></th>
                                <td><?php echo $results->nome; ?></td>
                                <td><?php echo $results->email; ?></td>
                                <td><?php echo $results->telefone; ?></td>
                                <td align="center"><input type="checkbox" id="id[<?php echo $results->id; ?>]" name="id[<?php echo $results->id; ?>]" value="<?php echo $results->id; ?>"></td>
                                
                                <td align="center"><button type="button" class="btn btn-info text-white" onclick="location.href='editar.php?id=<?php echo $results->id; ?>'">Editar</button></td>
                            </tr>
                        <?php
                        } ?>
                    </tbody>
                </table>
                <button class="btn btn-danger">Excluir</button>
            </form>