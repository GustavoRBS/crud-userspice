<?php
require_once 'users/init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if(isset($user) && $user->isLoggedIn()){
}
$db->query("SELECT * FROM clientes WHERE id = '".$_REQUEST["id"]."'");
?>

</br></br>
<div class="container">
    <div class="row d-flex justify-content-center text-center">
        <div class="col-md">
            <h3>Editar cliente</h3>
            </br>
        </div>
    </div>
    <div class="row d-flex justify-content-center">
        <div class="col-md-4">
            <form method="post" action="update.php?id=<?php echo $_REQUEST["id"] ?>">
                <div class="form-group">
                    <label for="exampleFormControlInput1">Nome:</label>
                    <input type="text" class="form-control" name="nome" id="nome" value="<?php echo $db->results()[0]->nome; ?>" required>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput2">Email:</label>
                    <input type="text" class="form-control" name="email" id="email" value="<?php echo $db->results()[0]->email; ?>" required>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput3">Telefone:</label>
                    <input type="number" class="form-control" name="telefone" id="telefone" value="<?php echo $db->results()[0]->telefone; ?>" required>
                </div>
                </br><input type="submit" class="text-white btn bg-success" value="Salvar">
            </form></br>
            <div class="resposta"></div>
        </div>
    </div>
</div>